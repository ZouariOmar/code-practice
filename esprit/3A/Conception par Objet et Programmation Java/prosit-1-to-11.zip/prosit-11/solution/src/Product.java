// Product pkgname
package src;

public class Product {
  private int id;
  private String name;
  private double price;

  public Product() {
  }

  public Product(final int id, final String name, final double price) {
    this.id = id;
    this.name = name;
    this.price = price;
  }

  // ##########################
  // ### GETTERS && SETTERS ###
  // ##########################
  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public double getPrice() {
    return price;
  }

  public void setPrice(double price) {
    this.price = price;
  }

  @Override
  public String toString() {
    return String.format("Product: {id: %d, name: %s, price: %f}", id, name, price);
  }
} // Product class
